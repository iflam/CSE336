Homework 4
---------------
Itai Flam 54
Tom Biscardi 43

Servlet uses NetBeans. 
localhost:8080/WebApp/Servlet (in case that's needed?)

