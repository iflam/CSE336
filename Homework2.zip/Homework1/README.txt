Homework 2 Readme:
The View you want to use is 
Brooklyn Public Library Online Catalog.
The rest are static html pages that get linked when you
use any links.

